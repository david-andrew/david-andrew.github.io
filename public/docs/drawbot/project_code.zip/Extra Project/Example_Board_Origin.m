%example drawbot starting poses

%% x axis coordinate
tf_e1 = [ROTY(pi/2) [0 0.5 0.2]'; 0 0 0 1];
IK_control(ur5, tf_e1, {3});


%% y axis coordinate
tf_e2 = [ROTY(pi/2) [0.1 0.6 0.2]'; 0 0 0 1];
IK_control(ur5, tf_e2, {3});


%% origin coordinate
tf_origin = [ROTY(pi/2) [0 0.6 0.2]'; 0 0 0 1];
IK_control(ur5, tf_origin, {3});


