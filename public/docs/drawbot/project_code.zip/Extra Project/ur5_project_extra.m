%currently just experiments for creating contours from images for a drawbot

clc
clear
close all

global DEBUG 
DEBUG = true;

rosshutdown
rosinit
ur5 = ur5_interface();
ur5.init_gripper();

gui = DrawBotDriverGUI;
gui.ur5 = ur5;



%{

im_res = 100;

im = imread('/home/dsamson4/Downloads/spiral.jpg');
im = imresize(im, [im_res im_res]); scale = 0.1/im_res;
if size(im,3) == 3  %if rgb image, convert to grayscale
    im = rgb2gray(im);
end

figure
imshow(im);
figure
[C h] = contour(im',1); %only extract one layer for testing
camroll(-90);
h.LineColor = 'black';


%set the ur5 to the given block target from the assignment pdf first
gst1 = [0 -1 0 -0.3; 0 0 1 0.39; -1 0 0 0.12; 0 0 0 1];
A = ur5InvKin(gst1);
theta = A(:,1);

[r, t] = move_fastest(ur5, theta, 3);
wait_for_goal(ur5, theta);



gsb = ur5.get_current_transformation('base_link', 'T');
R = gsb(1:3,1:3);
gsb = gsb * [ROTZ(pi)*ROTY(-pi/2) [0 0 0]'; 0 0 0 1];

draw_contour(ur5, C, gsb, R, scale)

%}
