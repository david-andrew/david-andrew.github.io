function [ G_lift ] = lift_transform( G, lift_height )
%lift_transfomr returns the transformation matrix lifted by a height
%   Input args:
%       G - the 4x4 transform matrix to lift
%       lift_height - how far away from the board to move the arm
%   Output args:
%       G_lift - the resulting 4x4 transform matrix

    G_lift = G * [eye(3) [-lift_height 0 0]'; 0 0 0 1];

end

