function [ G, pt, x, y ] = first_in_contour( C, tf_board, Rst, scale )
%first_in_contour returns the transform to the first point in the contour
%   Input args:
%       C - the contour matrix (formatted as from contourc())
%       tf_board - transformation matrix to the origin of the board
%       scale - size scale of the contour
%   Output args:
%       G - the transform representing the first point on the board

    x = C(1,2) * scale; 
    y = C(2,2) * scale;
    pt = tf_board * [x y 0 1]';
    G = [[Rst; 0 0 0] pt];

end

