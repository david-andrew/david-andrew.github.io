function [ result ] = draw_contour( ur5, C, tf_board, Rst, scale )
%draw_contour draws the contours C with origin tf_board
%   Input args:
%       ur5 - handle to the ur5 interface
%       C - the contour matrix (follows the format of contourc())
%       tf_board is the transform from base_link to the board origin
%       Rst is the fixed rotation of the end effector relative to base_link
%   Output args:
%       result - 0 if unsuccessful, else 1

    %for displaying the current contour being drawn
    figure
    
    threshold = 0.03;
    lift_height = 0.02; %lift marker 2.5 cm between contours
    interpolate = 1; %number of points to interpolate between actual points
    
    %if next point is too far, lift pen
    %next_x = C(1,2)*scale; next_y = C(2,2)*scale;
    %next_pt = tf_board*[next_x next_y 0 1]';
    %next_G = [[Rst; 0 0 0] next_pt];
    Gst = first_in_contour(C, tf_board, Rst, scale); 
    

    %move to slightly above next point
    %Glift = next_G * [eye(3) [-lift_height 0 0]'; 0 0 0 1];
    Glift = lift_transform(Gst, lift_height);
    IK_control(ur5, Glift, {5});
    wait_for_goal(ur5, Glift, threshold);
    
    
    fprintf('Press button to begin drawing\n')
    waitforbuttonpress
    
    fprintf('starting draw image\n')
    
    %place pen
    Gst = lift_pen(ur5, -lift_height);
    IK_control(ur5, Gst, {1});
    wait_for_goal(ur5, Gst, threshold);
    
    
    % if C has contours, then keep drawing 
    while ~isempty(C)
        pts = C(2,1); %how many points are contained in this contour
        % to be replaced with teaching the bounds of the board from the origin
        
        % ignore contour if it has less than 10 points
        if pts < 15
            %if this was the last contour, then the function is complete
            if length(C(1,2:end)) == pts
                C = [];
            else
                %get the rest of the contours left for the next iteration
                C = C(:,pts+2:end); 
            end
            
            continue
        end
        
        %if currently too far from next contour, lift pen and move to next
        [ next_G, pt, ~, ~ ] = first_in_contour(C, tf_board, Rst, scale);
        cur_G = ur5.get_current_transformation('base_link', 'T');
        cur_pt = cur_G(1:4,4);
        if norm(pt - cur_pt) > 0.01 %next contour point is too far away
            %lift pen up
            Gst = lift_pen(ur5, lift_height);
            IK_control(ur5, Gst, {0.5});
            %wait_for_goal(ur5, Gst, threshold);
            pause(0.5)

            %move to slightly above next point
            Gst = lift_transform(next_G, lift_height);
            IK_control(ur5, Gst, {1});
            %wait_for_goal(ur5, Gst, threshold);
            pause(1)
            
            %place pen
            Gst = lift_pen(ur5, -lift_height);
            IK_control(ur5, Gst, {1});
            %wait_for_goal(ur5, Gst, threshold);
            pause(0.5)
            
        end
        
        
        
        %get the 2D path of the contour
        x = C(1,2:pts+1) * scale;
        y = C(2,2:pts+1) * scale;
        
        %plot the contour to be drawn
        
        plot(y,-x);
        title('Current Contour')
        axis equal
        %camroll(90);

        %contour in the local board frame (homogeneous coords)
        local_path = [x; y; zeros(1,pts); ones(1,pts)];

        %contour path relative to the robot base frame (homogeneous coords)
        world_path = tf_board*local_path;

        %currently not working
        %trajectory_control(ur5, Rst, world_path, 3);
        
        %for each point in the contour, command the ur5 to that point
        for c = 1:pts
            pt = world_path(1:3,c);
            
            G0 = ur5.get_current_transformation('base_link', 'T');
            x0 = G0(1,4);
            y0 = G0(2,4);
            z0 = G0(3,4);
        
            x1 = pt(1);
            y1 = pt(2);
            z1 = pt(3);
        
        
            for i = linspace(0, 1, interpolate)
                xi = interp1([0 1], [x0 x1], i);
                yi = interp1([0 1], [y0 y1], i);
                zi = interp1([0 1], [z0 z1], i);
            
                pti = [xi yi zi]';
                
                gbc = [Rst, pti; 0 0 0 1]; %transform from base to contour
                IK_control(ur5, gbc, {1});
            end
        end        
        
        %reset for next contour in the C-matrix
        
        
        if length(C(1,2:end)) == pts
            %if this was the last contour, then the function is complete
            C = [];
        else
            %get the rest of the contours left for the next iteration
            C = C(:,pts+2:end); 
        end
    end

    
    fprintf('FINISHED DRAWING CONTOURS\n')
    
    ur5.move_joints(ur5.home, 7);
    result = 1;
    
    

end

