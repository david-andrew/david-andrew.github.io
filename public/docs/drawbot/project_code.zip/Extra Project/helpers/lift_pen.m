function [ G_lift ] = lift_pen( ur5, lift_height)
%lift_pen returns the transformation matrix that is lifted from the board
%   Input args:
%       ur5 - handle to ur5 interface
%       lift_height - how far away from the board to move the arm
%   Output args:
%       G_lift - the resulting 4x4 transform matrix

    G_start = ur5.get_current_transformation('base_link', 'T');
    G_lift = G_start * [eye(3) [-lift_height 0 0]'; 0 0 0 1];

end

