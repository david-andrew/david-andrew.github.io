% inverse test

%% starting position
%gst0 = [0 -1 0 0.47; 0 0 1 0.55; -1 0 0 0.12; 0 0 0 1];
%g_T_toolK = [ROTX(-pi/2)*ROTY(pi/2) [0 0 0]'; 0 0 0 1];
%gst0 = gst0 * g_T_toolK;
%A = ur5InvKin(gst0);
%theta = A(:,1);

%[r, t] = move_fastest(ur5, theta, 3);
%wait_for_goal(ur5, theta);

%% final position

%gst1 = [0 -1 0 -0.3; 0 0 1 0.39; -1 0 0 0.12; 0 0 0 1];
%gst1 = gst1 * g_T_toolK;
%A = ur5InvKin(gst1);
%theta = A(:,1);

%[r, t] = move_fastest(ur5, theta, 3);
%wait_for_goal(ur5, theta);

%% move to home position
%theta = ur5.home+ones(6,1)*0.5;
%joint=[-1.2204;-1.9411;2;-0.7;1.3;0.17];
%ur5.move_joints(joint,4);
%[r, t] = move_fastest(ur5, ur5_home, 3);
%wait_for_goal(ur5, ur5_home);
%%
joints1 =[-1.2204 -1.9411 -2.0093 -0.6588 1.3006 0.1724]';
ur5.move_joints(joints1,4);
%%
joints2 = [-2.1040 -1.9412 -1.9624 -0.6587 1.3004 0.1724]';
ur5.move_joints(joints2,4)
%%
ur5.move_joints(joints1 +[0 pi/8 pi/8 0 0 0]', 4);

%%
ur5.move_joints(ur5_home, 4);
