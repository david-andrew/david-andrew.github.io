%driver script for the final robot devices lab
clear
clc
close all

global DEBUG 
DEBUG = true;

%set up the ur5 interface object to use
rosshutdown
rosinit
ur5 = ur5_interface();
ur5.init_gripper();

if norm(ur5.get_current_joints()) > 50
    error('ur5 joint angles are currently set to large. please reset rvis')
end

%open a GUI for controlling the program
gui = DriverGUI;

%pass the current instance of the ur5 interface to the GUI
gui.ur5 = ur5;

%GUI performs the rest of the control for the lab