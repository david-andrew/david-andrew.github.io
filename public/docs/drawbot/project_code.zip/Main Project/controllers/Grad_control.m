function [ result ] = Grad_control( ur5, gst_target, args, K, threshold, scale )
%Grad_control moves the UR5 to the destination with differential kinematics
%   Input args:
%       ur5 - handle to the ur5_interface object
%       destination - the 4x4 Homogeneous destination to move the ur5 to
%       args{1} = gain - the gain for the resolved rate controller
%       args{2} = translation threshold (meters) for successful motion
%       args{3} = rotational threshold (radians) for successful motion
%   Output args:
%       result - was the operation a success. 1 for yes, 0 for no

%{    
if nargin == 3 
        gain = args{1};
        %vf = args{2};
        %wf = args{3};
        
    elseif nargin == 2
        gain = 0.3;      %controller gain
        %vf = 0.01;      %final twist translation threshold (1 cm)
        %wf = pi/24;     %final twist angle threshold (15 degrees)
    else
        error('Expected at 2 or 3 arguments')
    end
   %} 
    
    
    global DEBUG %declare debug to access global version
    if DEBUG
        fprintf('using Gradient Control to move the UR5 to destination: ')
        gst_target
    end
    
    
    %create a frame to show the target
    %tf_target_1 = tf_frame('base_link','target1',gst_target);

    g_T_toolK = [ROTX(-pi/2)*ROTY(pi/2) [0 0 0]'; 0 0 0 1]; 
    gst_target = gst_target * g_T_toolK;
    %ur5InvKin(gst_target)
    
    %create a frame to show the target
    %tf_target_2 = tf_frame('base_link','target2',gst_target);
    
    
    q = ur5.get_current_joints();
    step = 0.5;
    i = 0;
    q_next = q;
    while(1)
        q_current = q_next;
        if abs(det(f_ur5BodyJacobain( q_current ))) < 0.0001
            fprintf('singularity')
            finalerr = -1;
            break
        end
        i = i + 1;
        xi = f_getXi(gst_target \  f_ur5FwdKin(q_current) );
        v = xi(1 : 3);
        w = xi(4 : 6);
        J = f_ur5BodyJacobain( q_current );
        q_next = q_current - K * step * transpose(J) * xi;
        time_interval = max(abs(q_next-q_current))/(pi*ur5.speed_limit)*1.01*scale;
        if( time_interval < 0.5)
            ur5.move_joints(q_next, 0.5)
            pause(0.5)
        else
            ur5.move_joints(q_next,time_interval);
            pause(time_interval);
        end
        if (norm(w) < threshold) && (norm(v) < threshold)
            fprintf('positional error:')
            finalerr = norm(v);
            break
        end
    end
  
    

