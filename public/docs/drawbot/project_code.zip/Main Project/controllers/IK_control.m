function [ result ] = IK_control( ur5, gst_target, args, ~, ~, ~)
%IK_control moves the UR5 to the destination with inverse kinematic control
%   Input args:
%       ur5 - handle to the ur5_interface object
%       destination - the destination to move the ur5 to (joint angles?)
%       args{1} = speed - the time in seconds that the action should take. 
%       if this is zero, the controller moves the arm as fast as allowable
%   Output args:
%       result - was the operation a success. 1 for yes, 0 for no


    if nargin >= 3
        speed = args{1};
    elseif nargin == 2
        speed = 0.1;
    else
        error('Expected at 2 or 3 arguments')
    end
    
    threshold = 0.1;
    
    
    global DEBUG %declare debug to access global version
    if DEBUG
        fprintf('Using Inverse Kinematics to move the UR5 to destination: ')
        gst_target
    end
        
    
    
    %create a frame to show the target
    %tf_target = tf_frame('base_link','target',gst_target);
    
    
    %transformation from {T} to keating tool 
    g_T_toolK = [ROTX(-pi/2)*ROTY(pi/2) [0 0 0]'; 0 0 0 1]; 

    
    %get the current transform of the UR5 as the starting position
    %gst_start = ur5.get_current_transformation('S','T');
    %g_start_des=gst_start*g_T_toolK;                        %transform to real start position frame

    
    %gst_target is passed into the function call
    %apply tool offset
    g_target_des=gst_target*g_T_toolK;
    
    
    %theta_start = ur5InvKin(gst_start);
    theta_target = ur5InvKin(g_target_des);
    

    %select the best theta
    theta_target = get_best_theta(ur5.get_current_joints, theta_target);
    
    %move the UR5 to the goal
    [result, ~] = move_fastest(ur5, theta_target, speed);
    result = result & wait_for_goal(ur5, theta_target, threshold);


end

