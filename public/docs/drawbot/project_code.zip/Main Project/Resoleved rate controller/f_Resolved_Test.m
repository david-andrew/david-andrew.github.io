clear
clc
close all


rosshutdown
rosinit
ur5 = ur5_interface();

joints_start =[-1.2204 -1.9411 -2.0093 -0.6588 1.3006 0.1724]';

joints_target = [-2.1040 -1.9412 -1.9624 -0.6587 1.3004 0.1724]';
% move to random nonsingular position
ur5.move_joints(joints_start+[0 pi/10 pi/10 0 0 0]', 5);

% pick positon
gst_start = f_ur5FwdKin(joints_start)
frame_start = tf_frame('base_link', 'frame_start', gst_start);
frame_start_above = tf_frame('base_link', 'frame_start_above', gst_start);
% place position
gst_target = f_ur5FwdKin(joints_target);
frame_target = tf_frame('base_link', 'frame_target', gst_target);
frame_target_above = tf_frame('base_link', 'frame_target_above', gst_target);
height = [0,0,0,0;0,0,0,0;0,0,0,0.1;0,0,0,0]; 
% pre_pick positon
gsttest_start = gst_start+height;
% pre_place position
gsttest_target = gst_target+height;




waitforbuttonpress;
f_ur5RRcontrol(gsttest_start, ur5)
waitforbuttonpress;
f_ur5RRcontrol(gst_start,  ur5)
waitforbuttonpress;
f_ur5RRcontrol(gsttest_start,  ur5)
waitforbuttonpress;
% start placing
f_ur5RRcontrol(gsttest_target,  ur5)
waitforbuttonpress;
f_ur5RRcontrol( gst_target, ur5)
waitforbuttonpress;
f_ur5RRcontrol(gsttest_target, ur5)
waitforbuttonpress;
ur5.move_joints(ur5.home, 6)
%gsttest_start, ur5gsttest_start, ur5


%pause(5);
%fprintf('moving to start\n')
%f_ur5RRcontrol(gst_start, ur5);
%waitforbuttonpress;
%fprintf('moving to target\n')
%f_ur5RRcontrol(gst_target, ur5);
%pause(10);

