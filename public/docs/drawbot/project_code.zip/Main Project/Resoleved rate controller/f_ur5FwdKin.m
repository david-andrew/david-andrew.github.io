function g = f_ur5FwdKin(joints)
% input: joints is 6*1 vector where joints (i) correspond to joint i in
% gazebo setting.
% output: g is 4*4 transformation matrix relative to base_link
w1 = [0; 0; 1];
w2 = [0; 1; 0];
w3 = [0; 1; 0];
w4 = [0; 1; 0];
w5 = [0; 0; -1];
w6 = [0; 1; 0];

q1 = [0; 0; 0];
q2 = [0; 0; 0.0892];
q3 = [0.425; 0.1093; 0.0892];
q4 = [0.817; 0.1093; 0.0892];
q5 = [0.817; 0.1093; 0.0892];
q6 = [0.817; 0.1093; 0.00555];

tc1 = [cross(q1,w1);w1];
tc2 = [cross(q2,w2);w2];
tc3 = [cross(q3,w3);w3];
tc4 = [cross(q4,w4);w4];
tc5 = [cross(q5,w5);w5];
tc6 = [cross(q6,w6);w6];

    function expot = expo(theta,w,tc)
        I = [1 0 0 0; 0 1 0 0; 0 0 1 0; 0 0 0 1];
        twist = [0 -w(3) w(2) tc(1); w(3) 0 -w(1) tc(2); -w(2) w(1) 0 tc(3); 0 0 0 0];
        expot = I + theta* twist + (1-cos(theta))*(twist*twist) + (theta-sin(theta))*twist*twist*twist;
    end

expo1 = expo(joints(1),w1,tc1);
expo2 = expo(joints(2),w2,tc2);
expo3 = expo(joints(3),w3,tc3);
expo4 = expo(joints(4),w4,tc4);
expo5 = expo(joints(5),w5,tc5);
expo6 = expo(joints(6),w6,tc6);

gst0 = [-1 0 0 0.817; 0 0 1 0.1918; 0 1 0 -0.00555; 0 0 0 1]; 


g = expo1*expo2*expo3*expo4*expo5*expo6*gst0;
        
end
