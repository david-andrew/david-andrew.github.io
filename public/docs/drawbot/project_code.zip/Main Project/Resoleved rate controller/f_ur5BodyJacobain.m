function [J] = f_ur5BodyJacobain(q)
%Purpose: Compute the Jacobian matrix for the UR5.
%   q: a set of 6*1 joint space vector
%   output J:Body Jacobian(6*6)

w1 = [0; 0; 1];
w2 = [0; 1; 0];
w3 = [0; 1; 0];
w4 = [0; 1; 0];
w5 = [0; 0; -1];
w6 = [0; 1; 0];

q1 = [0; 0; 0];
q2 = [0; 0; 0.0892];
q3 = [0.425; 0.1093; 0.0892];
q4 = [0.817; 0.1093; 0.0892];
q5 = [0.817; 0.1093; 0.0892];
q6 = [0.817; 0.1093; 0.00555];

tc1 = [cross(q1,w1);w1];
tc2 = [cross(q2,w2);w2];
tc3 = [cross(q3,w3);w3];
tc4 = [cross(q4,w4);w4];
tc5 = [cross(q5,w5);w5];
tc6 = [cross(q6,w6);w6];

    function expot = expo(theta,w,tc)
        I = [1 0 0 0; 0 1 0 0; 0 0 1 0; 0 0 0 1];
        twist = [0 -w(3) w(2) tc(1); w(3) 0 -w(1) tc(2); -w(2) w(1) 0 tc(3); 0 0 0 0];
        expot = I + theta* twist + (1-cos(theta))*(twist*twist) + (theta-sin(theta))*twist*twist*twist;
    end

expo1 = expo(q(1),w1,tc1);
expo2 = expo(q(2),w2,tc2);
expo3 = expo(q(3),w3,tc3);
expo4 = expo(q(4),w4,tc4);
expo5 = expo(q(5),w5,tc5);
expo6 = expo(q(6),w6,tc6);

gst0 = [-1 0 0 0.817; 0 0 1 0.1918; 0 1 0 -0.00555; 0 0 0 1]; 

    function AdInv = adinv(g)
        RT = transpose(g(1:3,1:3));
        P = [g(1:3,4)];
        Phat = [0 -P(3) P(2); P(3) 0 -P(1); -P(2) P(1) 0];
        zero = [0 0 0; 0 0 0; 0 0 0];
        AdInv = [RT -RT*Phat; zero RT];
    end

tt1 = adinv(expo1*expo2*expo3*expo4*expo5*expo6*gst0)*tc1;
tt2 = adinv(expo2*expo3*expo4*expo5*expo6*gst0)*tc2;
tt3 = adinv(expo3*expo4*expo5*expo6*gst0)*tc3;
tt4 = adinv(expo4*expo5*expo6*gst0)*tc4;
tt5 = adinv(expo5*expo6*gst0)*tc5;
tt6 = adinv(expo6*gst0)*tc6;

J = [tt1 tt2 tt3 tt4 tt5 tt6];
end

