function Xi = f_getXi(g)
%Purpose: Take the homogeneous transformation matrix and extract the
%unscaled twist
% Input: g: a homogeneours transformation
% Output: xi: the unnormed twist
[V,D] = eig(g);
Dxi = [log(D(1,1)) 0 0 0; 0 log(D(2,2)) 0 0; 0 0 log(D(3,3)) 0; 0 0 0 log(D(4,4))];
twist = V*Dxi/V;
Xi = [twist(1:3,4); twist(3,2); twist(1,3); twist(2,1)];
end

