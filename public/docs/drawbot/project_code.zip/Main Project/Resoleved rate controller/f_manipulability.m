function [ mu ] = manipulability( J, measure )
%MANIPULABILITY 
%   \
s = svd(J);

if (measure == "sigmamin")
    mu = min(s);
    return;
end

if (measure == "detjac")
    mu = det(J);
    return;
end

if (measure == "invcond")
    mu = min(s)/max(s);
    return;
end


end

