function finalerr = ur5RRControl(gdesired, ur5)
%UR5RRCONTROL Implement a discret-time resolved rate control system
%   Inputs: gdesired: homogeneous transformation of the desired end-effector pose gst
%   Outputs: finalerr: -1 if there is a failure or if the convergence
%                       achieved, final positional error in cm



k = 0;
q = ur5.get_current_joints();
% thre_v = 0.05;
% thre_w = 0.05;
K=1.7
thresh = 0.01;
tstep = 0.5;
q_next = q;
while(1)
    q_curr = q_next;
    gst = f_ur5FwdKin(q_curr);
    xi = f_getXi(gdesired \ gst);
    v = xi(1:3);
    w = xi(4:6);
    J = f_ur5BodyJacobain(q_curr);
    if abs(det(J)) < 0.001
        finalerr = -1;
        return;
    end
    q_next = q_curr - K*tstep*(J\xi);
    time_interval = max(max(abs(q_next-q_curr)))/(pi*ur5.speed_limit)*1.01*60;
    ur5.move_joints(q_next, time_interval);
    pause(time_interval);
    if(norm(v) < thresh && norm(w) < thresh)
        q_dest = ur5.get_current_joints();
        gst = f_ur5FwdKin(q_dest);
        finalerr = norm(gst(1:3,4) - gdesired(1:3,4));
        break;
    end
    k = k + 1;
end

end