function [ result, time ] = move_fastest( ur5, target, time )
%move_fastest moves the ur5 to the desired position as quickly as possible
%   Input args:
%       ur5 is the interface object for the UR5
%       target is the joint target the ur5 will be moving to
%       args{0} = time (optional) - is the minimum time the action should take.
%       i.e. if the arm can move in time, then it will, else if it is too
%       fast, then the function will find the minimum legal time
%   Output args:
%       result is whether the operation was successful. 
%       1 for success
%       0 for failure, which will occur if it takes too much time to move
%       time is the interval the arm will take to move



    if nargin == 2
        time = 0.01;    %play with this initial starting interval
    elseif nargin ~= 3
        error('expected at 2 or 3 arguments')
    end

    
    %try to move the arm with successively larger time intervals
    while time < 100    % if longer than 100 seconds, return an error
        try
            ur5.move_joints(target, time);
            break;
        catch
            time = time * 2;    %try again with a larger time step
        end
    end
    
    
    %result for if the arm was successfully moved
    if time > 100
        result = 0;
    else
        result = 1;
    end
    
end

