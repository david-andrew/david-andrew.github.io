function [ practical ] = pos_practical( theta )
%pos_practical determines if a particular joint position is practical
%   Input args:
%       theta - 6x1 vector of ur5 joint angles to check
%   Output args:
%       practical - bool for whether or not the pose is practical

    %perform a series of practicability tests
    practical = true;
    practical = practical & theta(2) < 0;
    practical = practical & theta(2) > -pi;
    %practical = practical & ...

end

