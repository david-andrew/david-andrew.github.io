function [ home ] = ur5_home( )
%ur5_home returns a custom home position for the ur5
%   the home position is a 6x1 vector of joint angles that is a
%   configuration without an singularities
    home = [1.2234 -1.1064 1.3199 -1.15 -1.08 0]';

end

