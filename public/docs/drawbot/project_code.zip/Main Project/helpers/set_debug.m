function [ ] = set_debug( value )
%set_debug sets the value of the global DEBUG parameter
%   this is mainly so that the GUI can control the DEBUG value
%   Input args:
%       value - boolian state to set DEBUG to

global DEBUG
DEBUG = value;

end

