function [ result ] = wait_for_goal( ur5, target, threshold )
%wait_for_goal pauses the program executrion until the UR5 is at the goal
%   Input args:
%       ur5 - handle to the ur5 interface object
%       target - the joint angles the ur5 is moving to
%       target can also be a 4x4 homogeneous transform of the goal
%       threshold (optional) - norm of how close to the target to wait for
%   Ouptut args:
%       result - did the arm reach the target. fails if it takes more than
%       100 seconds

    if nargin < 3
        threshold = 0.01;
    elseif nargin < 2
        error('expected at least 2 arguments')
    end

    %start a timer
    tic;

    if size(target) == [6 1]
        while norm(ur5.get_current_joints - target) > threshold && toc < 10
            %do nothing, wait for next iteration
        end
    elseif size(target) == [4 4]
        while norm(reshape(ur5.get_current_transformation('base_link', 'T') - target, 16, 1)) > threshold && toc < 10
            %do nothing
            ur5.get_current_transformation('base_link', 'T')
            target
        end
    else
        error('unrecognized target size');
    end


    %if it is less than the elapsed time, the movement was successful
    if toc < 10
        result = 1;
    else
        result = 0;
    end

end

