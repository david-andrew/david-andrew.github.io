function [ above_location ] = get_above( location, dist )
%get_above returns the transformation (or joint angles?) that is above the
%specified location
%   Input:
%       location - the target location to work relative to
%       dist - specifies how high above the location to calculate. default
%       is 10 cm
%   Output:
%       above_location - the location that is above the specified location
    
    %set default value for dist
    if nargin < 2
        dist = 0.1;
    end
    
    

    %make copy of location
    above_location = location;
   
    above_location(3,4) = above_location(3,4) + dist; 
    

end

