%enumeration containing the different control methods available
classdef ctrl
    enumeration
        IK, DK, Grad        %inverse kin, diff kin, gradient
    end
end