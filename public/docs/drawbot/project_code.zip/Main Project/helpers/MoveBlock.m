function [  ] = MoveBlock( ur5, init, final, control )
%MoveBlock moves the block from initial position to final position
%   Input arguements:
%       ur5 - handle to the ur5 interface for the control functions
%       init - 4x4 homogeneous transform for the UR5 at the block starting
%       position
%       final - 4x4 homogeneous transform for the UR5 at the block final
%       position
%       control - ctrl enum representing the type of control to use during
%       the action of moving the block


    global DEBUG %declare debug to access global version
    
    %useful parameters to be passed into the controller
    speed = 5;  %time each operation should take
    gain = 0.1;
    
    %other parameters
    gripper_interval = 1;   %time to open the gripper
    threshold = 0.1;        %how close to the goal does the arm need to be
    
    %get a function handle to the correct control function
    %also construct arguments to pass into the function 
    %(in addition to the ur5 interface and goal)
    switch control
        case ctrl.IK
            ctrl_func = @IK_control;
            args = {speed}; %parameter variable to be passed in
            
        case ctrl.DK
            ctrl_func = @DK_control;
            args = {gain, threshold};  %parameter variable to be passed in
            
        case ctrl.Grad
            ctrl_func = @Grad_control;
            args = {};
            
        otherwise
            error('unrecognized control type specified');
    end
    
    
    
    
    
    fprintf('\n\nBeginning move block algorithm\n\n')
    
    %move to home position before starting to move block
    fprintf('Moving to custom home position. Press button to continue\n\n')
    ur5.move_joints(ur5_home, 7);
    waitforbuttonpress
    
    
    %open gripper
    fprintf('Opening gripper. Press button to continue\n\n')
    ur5.open_gripper();
    waitforbuttonpress
    
    
    %move to above block starting position
    tf_target = tf_frame('base_link','target', get_above(init));
    fprintf('Moving to above ititial block position. Press button to continue\n\n')
    ctrl_func(ur5, get_above(init), args, 0.5,0.015,120);   % for gradient
    waitforbuttonpress
    
    
    %move down to enclose the block
    tf_target.move_frame('base_link', init)
    fprintf('Moving to ititial block position. Press button to continue\n\n')
    ctrl_func(ur5, init, args, 0.8,0.005,120);    % for gradient control
    waitforbuttonpress
    
    
    %close the gripper
    fprintf('closing gripper. press any key to continue\n\n')
    ur5.close_gripper();
    waitforbuttonpress
    
    
    %move to above block starting position
    tf_target.move_frame('base_link', get_above(init))
    fprintf('Lifting block up. Press button to continue\n\n')
    ctrl_func(ur5, get_above(init), args,0.8,0.015,100);
    waitforbuttonpress
    
    
    %move the ur5 to above the end position
    tf_target.move_frame('base_link', get_above(final))
    fprintf('Moving to above final block position. Press button to continue\n\n')
    ctrl_func(ur5, get_above(final), args,0.8,0.015,70);
    waitforbuttonpress
    
    
    %move the ur5 to the final location
    tf_target.move_frame('base_link', final)
    fprintf('Lowering Block. Press button to continue\n\n')
    ctrl_func(ur5, final, args,0.8,0.005,120);
    waitforbuttonpress
    
    
    %open the gripper to drop the block
    fprintf('Opening gripper. Press button to continue\n\n')
    ur5.open_gripper();
    waitforbuttonpress
    
    
    %move the ur5 to above the end position
    tf_target.move_frame('base_link', get_above(final))
    fprintf('Lifting arm away from block. Press button to continue\n\n')
    ctrl_func(ur5, get_above(final), args,0.8,0.015,100);
    waitforbuttonpress
    
    
    %move the ur5 to the home position
    fprintf('Moving to custom home position. Move Block is complete\n\n')
    ur5.move_joints(ur5_home, 7);

    
end

