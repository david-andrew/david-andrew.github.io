function [ best ] = get_best_theta( current, candidates )
%get_best_theta returns the best theta value relative to the current value
%   Input args:
%       current - 6x1 vector of the current ur5 joint position
%       possible - 6x6 vector of possible joint angles for the target
%   Output args
%       best - is the best choice for the target. this is determined by the
%       distance from the current position, as well as practicality

    %select the best target theta
    best_norm = 1000000;
    best_ind = -1;
    
    for i = 1:8
        if pos_practical(candidates(:,i))
            
            n = norm(current - candidates(:,i));
            
            if n < best_norm     %check if this is the shortast path in joint space
                best_norm = n;
                best_ind = i;
            end
        end
    end
    
    best = candidates(:,best_ind);

end